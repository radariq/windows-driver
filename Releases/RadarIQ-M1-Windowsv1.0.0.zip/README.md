The files in this directory (radariq-m1.inf and radariq-m1.cat) are the RadarIQ M1 drivers
for Windows 7 and below. To install these drivers:

1. If you downloaded the drivers in a ZIP file, extract it to a temporary folder
   on your computer.

2. Open the folder containing these files. Right click on "radariq-m1.inf" and
   select "Install".

3. Windows will ask you whether you want to install the drivers. Click "Install"
   (Windows 7, and Vista) or "Continue Anyway" (Windows XP).

4. Windows will not tell you when the installation is complete, but it should be
   done after a few seconds.
